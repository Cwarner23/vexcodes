/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Tim Johnson                                               */
/*    Created:      Wed Sep 20 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontLeft            motor         7               
// BackLeft             motor         4               
// BackRight            motor         1               
// FrontRight           motor         9               
// Controller1          controller                    
// Motor6               motor         6               
// Motor8               motor         8               
// middleLeft_motor10   motor         10              
// middleRight_motor11  motor         14              
// ---- END VEXCODE CONFIGURED DEVICES ----
#include "cmath"
using namespace vex;
competition Competition;
float myVariable;


// "when driver control" hat block
int ondriver_drivercontrol_0() {
  // bumper motors
  liftmotor1.setVelocity(100, rpm);
  liftmotor2.setVelocity(100, rpm);
  
  intake.setVelocity(600, rpm);
  flyWheel.setVelocity(600, rpm);
  // driveTrain motors
  FrontLeft.setVelocity(200, rpm);
  BackLeft.setVelocity(200, rpm);
  BackRight.setVelocity(200, rpm);
  BackLeft.setVelocity(200, rpm);



  FrontLeft.spin(forward);
  BackLeft.spin(forward);
  BackRight.spin(forward);
  FrontRight.spin(forward);
  

  bool toggle = false;
  bool latch = false;

  bool toggle2 = false;
  bool latch2 = false;

  while (1) {
    FrontLeft.setVelocity((Controller1.Axis1.position() + Controller1.Axis3.position()), percent);
    FrontRight.setVelocity((Controller1.Axis1.position() - Controller1.Axis3.position()), percent);
    
    BackLeft.setVelocity((Controller1.Axis1.position() + Controller1.Axis3.position()), percent);
    BackRight.setVelocity((Controller1.Axis1.position() - Controller1.Axis3.position()), percent);

    
    if(Controller1.ButtonR2.pressing()) { // 4 bar lift
      liftmotor1.spin(forward);
      liftmotor2.spin(reverse);
    } else if (Controller1.ButtonR1.pressing()) {
      liftmotor1.spin(reverse);
      liftmotor2.spin(forward);
    } else {
      liftmotor1.stop();
      liftmotor2.stop();
    }

    if (Controller1.ButtonL2.pressing()) { // intake
      intake.spin(reverse);
    } else if (Controller1.ButtonL1.pressing()) {
      intake.spin(forward);
    } else {
      intake.stop();
    }

    
    if (toggle){ // pnumatic
      pneumatic.set(true);
    } else {
      pneumatic.set(false);
    }
    if (Controller1.ButtonB.pressing()) {
      if (!latch) { 
        toggle = !toggle;
        latch = true;
          vex::task::sleep(200);
      } else {
        latch = false;
      }
    }
    if (Controller1.ButtonX.pressing()) {
      flyWheel.spin(reverse);
  
    }

    else {
      flyWheel.stop();
    }
    

       
    // if (toggle2){ // flywheel
    //   flyWheel.spin(forward);
    // } else {
    //     flyWheel.stop();
    // }
    // if (Controller1.ButtonX.pressing()) {
    //   if (!latch2) { 
    //     toggle2 = !toggle2;
    //     latch2 = true;
    //   } else {
    //     latch2 = false;
    //   }
    // }
  }
  return 0;
}

void driveForward(float num) {
  FrontLeft.spinFor(forward, num, degrees, false);
  BackLeft.spinFor(forward, num, degrees, false);
  
  BackRight.spinFor(forward, -num, degrees, false);
  FrontRight.spinFor(forward, -num, degrees, false);

}

void driveBackward(float num) {
  FrontLeft.spinFor(forward, -num, degrees, false);
  BackLeft.spinFor(forward, -num, degrees, false);
  
  BackRight.spinFor(forward, num, degrees, false);
  FrontRight.spinFor(forward, num, degrees, false);
}

void turnRight(float num) {
  FrontLeft.spinFor(forward, num, degrees, false);
  BackLeft.spinFor(forward, num, degrees, false);
  
  BackRight.spinFor(forward, num, degrees, false);
  FrontRight.spinFor(forward, num, degrees, false);

}

void turnLeft(float num) {
  FrontLeft.spinFor(forward, -num, degrees, false);
  BackLeft.spinFor(forward, -num, degrees, false);
  
  BackRight.spinFor(forward, -num, degrees, false);
  FrontRight.spinFor(forward, -num, degrees, false);

}
// "when autonomous" hat block
int onauton_autonomous_0() {
  liftmotor1.setVelocity(400, rpm);
  liftmotor2.setVelocity(500, rpm);

  intake.setVelocity(500, rpm);

  // driveTrain motors
  FrontLeft.setVelocity(200, rpm);
  BackLeft.setVelocity(200, rpm);
  FrontRight.setVelocity(200, rpm);
  BackRight.setVelocity(200, rpm);

  driveForward(2500);
  
  return 0;
}

void VEXcode_auton_task() {
  //Start the auton control task ....
  vex::task auto0(onauton_autonomous_0);
  while(Competition.isAutonomous() && Competition.isEnabled()) {this_thread::sleep_for(10);}
  auto0.stop();
  return;
}

void VEXcode_driver_task() {
  //Start the driver control task ....
  vex::task drive0(ondriver_drivercontrol_0);
  while(Competition.isDriverControl() && Competition.isEnabled()) {this_thread::sleep_for(10);}
  drive0.stop();
  return;
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  vex::competition::bStopTasksBetweenModes = false;

  Competition.autonomous(VEXcode_auton_task);
  Competition.drivercontrol(VEXcode_driver_task);
  //register event handlers

  return(0);
}